"""Provides the 1P API client implementation for interacting with Chronicle SOAR."""

# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

from typing import TYPE_CHECKING

from TIPCommon.rest.custom_types import HttpMethod

from .base_soar_api import BaseSoarApi

if TYPE_CHECKING:
    import requests
    from TIPCommon.types import ChronicleSOAR, SingleJson


class OnePlatformSoarApi(BaseSoarApi):
    """Chronicle SOAR API client using 1P endpoints."""

    def save_attachment_to_case_wall(self) -> requests.Response:
        """Save an attachment to the case wall using 1P API."""
        payload = {
            "caseAttachment": {
                "attachmentId": 0,
                "attachmentBase64": self.params.base64_blob,
                "fileType": self.params.file_type,
                "fileName": self.params.name,
            },
            "comment": self.params.description,
            "isImportant": self.params.is_important,
        }
        if getattr(self.chronicle_soar, "alert_id", None):
            payload["alertIdentifier"] = self.chronicle_soar.alert_id

        endpoint = f"api/1p/external/v1.0/cases/{self.params.case_id}/comments"
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def get_entity_data(self) -> requests.Response:
        """Get entity data using 1P API."""
        payload = {
            "identifier": self.params.entity_identifier,
            "type": self.params.entity_type,
            "environment": self.params.entity_environment,
            "lastCaseType": self.params.last_case_type,
            "caseDistributionType": self.params.case_distribution_type,
        }
        endpoint = "api/1p/external/v1.0/uniqueEntities:fetchFull"
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def get_full_case_details(self) -> requests.Response:
        """Get full case details using 1P API."""
        case_type = self.params.case_type
        if case_type == "alert":
            endpoint = f"api/1p/external/v1.0/cases/{self.params.case_id}/alerts"
        else:
            endpoint = f"api/1p/external/v1.0/cases/{self.params.case_id}"
        return self._make_request(HttpMethod.GET, endpoint)

    def get_case_attachments(self) -> requests.Response:
        """Get case attachments using 1P API."""
        endpoint = f"api/1p/external/v1.0/cases/{self.params.case_id}/activities"
        query_params = {}
        if self.params.filter:
            query_params = {"filter": self.params.filter}
        return self._make_request(HttpMethod.GET, endpoint, params=query_params)

    def get_installed_integrations_of_environment(self) -> requests.Response:
        """Get installed integrations of environment using legacy API."""
        endpoint = (
            f"api/1p/external/v1/integrations/{self.params.integration_identifier}/"
            "integrationInstances"
        )
        name =  (
            "*" if self.params.environment == "Shared Instances"
            else self.params.environment
        )
        params = {"filter": f"environment=\"{name}\""}
        return self._make_request(HttpMethod.GET, endpoint, params=params)

    def get_connector_cards(self) -> requests.Response:
        """Get connector cards using legacy API"""
        endpoint = (
            f"api/1p/external/v1/integrations/{self.params.integration_name}"
            f"/connectors/-/connectorInstances"
        )
        return self._make_request(HttpMethod.GET, endpoint)

    def get_federation_cases(self) -> requests.Response:
        """Get federation cases using legacy API"""
        endpoint = "api/1p/external/v1.0/legacyFederatedCases:legacyFetchCasesToSync"
        params = {"nextPageToken": self.params.continuation_token}
        return self._make_request(HttpMethod.GET, endpoint, params=params)

    def patch_federation_cases(self) -> requests.Response:
        """Patch federation cases using legacy API"""
        endpoint = (
            "api/1p/external/v1.0/legacyFederatedCases:legacyBatchPatchFederatedCases"
        )
        headers = {"AppKey": self.params.api_key} if self.params.api_key else None
        payload = {"cases": self.params.cases_payload }

        return self._make_request(
            HttpMethod.POST,
            endpoint,
            json_payload=payload,
            headers=headers,
        )

    def get_workflow_instance_card(self) -> requests.Response:
        """Get workflow instance card using legacy API"""
        endpoint = (
            "api/1p/external/v1.0/legacyPlaybooks:"
            "legacyGetWorkflowInstancesCards?format=camel"
        )
        payload = {
            "caseId": self.params.case_id,
            "alertIdentifier": self.params.alert_identifier,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def pause_alert_sla(self) -> requests.Response:
        """Pause alert sla"""
        alert = self.get_case_alerts().json()
        alert_id = alert.get("case_alerts")[0].get("id")
        endpoint = (
            f"api/1p/external/v1.0/cases/{self.params.case_id}/"
            f"alerts/{alert_id}:pauseSla"
        )
        payload = {
            "message": self.params.message,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def resume_alert_sla(self) -> requests.Response:
        """Resume alert sla"""
        alert = self.get_case_alerts().json()
        alert_id = alert.get("case_alerts")[0].get("id")
        endpoint = (
            f"api/1p/external/v1.0/cases/{self.params.case_id}/"
            f"alerts/{alert_id}:resumeSla"
        )
        payload = {
            "message": self.params.message,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def get_case_overview_details(self) -> requests.Response:
        """Get case overview details"""
        case_id = self.params.case_id
        case_data = {}
        endpoint_case = f"api/1p/external/v1.0/cases/{case_id}?expand=sla"
        endpoint_alert = f"api/1p/external/v1.0/cases/{case_id}/alerts"
        case_data = self._make_request(HttpMethod.GET, endpoint_case).json()
        endpoint_alert_data = self._make_request(HttpMethod.GET, endpoint_alert)
        case_data["alertCards"] = endpoint_alert_data.json()["alerts"]

        return case_data

    def remove_case_tag(self) -> requests.Response:
        """Remove case tag"""
        endpoint = (
            f"api/1p/external/v1.0/cases/{self.params.case_id}:removeTag"
        )
        payload = {
            "caseId": self.params.case_id,
            "tag": self.params.tag,
            "alertIdentifier": self.params.alert_identifier,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def change_case_description(self) -> requests.Response:
        """Change case description"""
        endpoint = (
            f"api/1p/external/v1.0/cases/{self.params.case_id}"
        )
        payload = {
            "displayName": self.params.displayname,
            "stage": self.params.stage,
            "priority": self.params.priority,
            "important": self.params.important,
            "assignee": self.params.assignee,
            "description": self.params.description,
            "incident": self.params.incident,
            "environment": self.params.environment,
            "moveEnvironment": {
                "shouldDeleteOldCase": True,
            }
        }
        return self._make_request(HttpMethod.PATCH, endpoint, json_payload=payload)

    def set_alert_priority(self) -> requests.Response:
        """Set alert priority"""
        endpoint = (
            "v1alpha/projects/a/locations/b/instances/c/"
            "legacySdk:legacyUpdateAlertPriority"
        )
        payload = {
            "caseId": self.params.case_id,
            "alertIdentifier": self.params.alert_identifier,
            "priority": self.params.priority,
            "alertName": self.params.alert_name,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def set_case_score_bulk(self) -> requests.Response:
        """Set case score bulk"""
        endpoint = (
            "v1alpha/projects/a/locations/a/instances/a/legacySdk:legacyUpdateCaseScore"
        )
        payload = {
            "caseScores": [
                {
                    "caseId": self.params.case_id,
                    "score": self.params.score,
                }
            ],
        }
        return self._make_request(HttpMethod.PATCH, endpoint, json_payload=payload)

    def get_integration_full_details(self) -> requests.Response:
        """Get integration full details"""
        endpoint = (
            "api/1p/external/v1.0/marketplaceIntegrations/"
            f"{self.params.integration_identifier}"
        )
        return self._make_request(HttpMethod.GET, endpoint)

    def get_integration_instance_details_by_id(self) -> requests.Response:
        """Get integration instance details by instance id"""
        endpoint = (
            "api/1p/external/v1.0/integrations/"
            f"{self.params.integration_identifier}/integrationInstances/"
            f"{self.params.instance_id}"
        )

        return self._make_request(HttpMethod.GET, endpoint)

    def get_integration_instance_details_by_name(self) -> SingleJson:
        """Get integration instance details by instance name"""
        endpoint = (
            "api/1p/external/v1.0/integrations/"
            f"{self.params.integration_identifier}/integrationInstances"
        )
        query_params = {
            "filter": f'displayName="{self.params.instance_display_name}"'
        }

        return self._make_request(HttpMethod.GET, endpoint, params=query_params)

    def get_users_profile(self) -> requests.Response:
        """Get users profile"""
        endpoint = "api/1p/external/v1.0/legacySoarUsers"
        query_params = {
            "filter": f"displayName={self.params.display_name}"
        }
        return self._make_request(HttpMethod.GET, endpoint, params=query_params)

    def get_case_alerts(self) -> requests.Response:
        """Get case alerts"""

        endpoint = (
            f"api/1p/external/v1.0/cases/{self.params.case_id}/caseAlerts"
        )
        query_params: dict[str, str] = {}
        if self.params.alert_identifier is not None:
            query_params = {
                "filter": f"identifier=\"{self.params.alert_identifier}\""
            }
        return self._make_request(HttpMethod.GET, endpoint, params=query_params)
